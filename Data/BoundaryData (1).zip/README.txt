Files:
england_ltla_2022.shp
england_ltla_2022.shx
england_ltla_2022.dbf
england_ltla_2022.prj

Areas:
England

This data is provided with the support of the ESRC and JISC and uses boundary material which is copyright of the Crown, the Post Office and the ED-LINE consortium.